#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddha_MomoZones[] cacheBadBuddha_MomoZones;

		
		public BadBuddha_MomoZones BadBuddha_MomoZones(bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			return BadBuddha_MomoZones(Input, enableUpdateChecks, bodyAverageRange, volumeAverageRange, changeBarColor, bodyStdDevs, hotThreshold, showZones, showDots, zoneLookback, enableAlerts, alertOnHotBar, alertOnZoneTest, alertOnZoneBreak, enableZoneInvalidation, consecutiveClosesToInvalidate, enableVolumeWeighting, minZoneOpacity, maxZoneOpacity, showZoneLabels, showVolumeOnLabel, showBodySizeOnLabel, labelFontSize);
		}


		
		public BadBuddha_MomoZones BadBuddha_MomoZones(ISeries<double> input, bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			if (cacheBadBuddha_MomoZones != null)
				for (int idx = 0; idx < cacheBadBuddha_MomoZones.Length; idx++)
					if (cacheBadBuddha_MomoZones[idx].EnableUpdateChecks == enableUpdateChecks && cacheBadBuddha_MomoZones[idx].BodyAverageRange == bodyAverageRange && cacheBadBuddha_MomoZones[idx].VolumeAverageRange == volumeAverageRange && cacheBadBuddha_MomoZones[idx].ChangeBarColor == changeBarColor && cacheBadBuddha_MomoZones[idx].BodyStdDevs == bodyStdDevs && cacheBadBuddha_MomoZones[idx].HotThreshold == hotThreshold && cacheBadBuddha_MomoZones[idx].ShowZones == showZones && cacheBadBuddha_MomoZones[idx].ShowDots == showDots && cacheBadBuddha_MomoZones[idx].ZoneLookback == zoneLookback && cacheBadBuddha_MomoZones[idx].EnableAlerts == enableAlerts && cacheBadBuddha_MomoZones[idx].AlertOnHotBar == alertOnHotBar && cacheBadBuddha_MomoZones[idx].AlertOnZoneTest == alertOnZoneTest && cacheBadBuddha_MomoZones[idx].AlertOnZoneBreak == alertOnZoneBreak && cacheBadBuddha_MomoZones[idx].EnableZoneInvalidation == enableZoneInvalidation && cacheBadBuddha_MomoZones[idx].ConsecutiveClosesToInvalidate == consecutiveClosesToInvalidate && cacheBadBuddha_MomoZones[idx].EnableVolumeWeighting == enableVolumeWeighting && cacheBadBuddha_MomoZones[idx].MinZoneOpacity == minZoneOpacity && cacheBadBuddha_MomoZones[idx].MaxZoneOpacity == maxZoneOpacity && cacheBadBuddha_MomoZones[idx].ShowZoneLabels == showZoneLabels && cacheBadBuddha_MomoZones[idx].ShowVolumeOnLabel == showVolumeOnLabel && cacheBadBuddha_MomoZones[idx].ShowBodySizeOnLabel == showBodySizeOnLabel && cacheBadBuddha_MomoZones[idx].LabelFontSize == labelFontSize && cacheBadBuddha_MomoZones[idx].EqualsInput(input))
						return cacheBadBuddha_MomoZones[idx];
			return CacheIndicator<BadBuddha_MomoZones>(new BadBuddha_MomoZones(){ EnableUpdateChecks = enableUpdateChecks, BodyAverageRange = bodyAverageRange, VolumeAverageRange = volumeAverageRange, ChangeBarColor = changeBarColor, BodyStdDevs = bodyStdDevs, HotThreshold = hotThreshold, ShowZones = showZones, ShowDots = showDots, ZoneLookback = zoneLookback, EnableAlerts = enableAlerts, AlertOnHotBar = alertOnHotBar, AlertOnZoneTest = alertOnZoneTest, AlertOnZoneBreak = alertOnZoneBreak, EnableZoneInvalidation = enableZoneInvalidation, ConsecutiveClosesToInvalidate = consecutiveClosesToInvalidate, EnableVolumeWeighting = enableVolumeWeighting, MinZoneOpacity = minZoneOpacity, MaxZoneOpacity = maxZoneOpacity, ShowZoneLabels = showZoneLabels, ShowVolumeOnLabel = showVolumeOnLabel, ShowBodySizeOnLabel = showBodySizeOnLabel, LabelFontSize = labelFontSize }, input, ref cacheBadBuddha_MomoZones);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddha_MomoZones BadBuddha_MomoZones(bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			return indicator.BadBuddha_MomoZones(Input, enableUpdateChecks, bodyAverageRange, volumeAverageRange, changeBarColor, bodyStdDevs, hotThreshold, showZones, showDots, zoneLookback, enableAlerts, alertOnHotBar, alertOnZoneTest, alertOnZoneBreak, enableZoneInvalidation, consecutiveClosesToInvalidate, enableVolumeWeighting, minZoneOpacity, maxZoneOpacity, showZoneLabels, showVolumeOnLabel, showBodySizeOnLabel, labelFontSize);
		}


		
		public Indicators.BadBuddha_MomoZones BadBuddha_MomoZones(ISeries<double> input , bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			return indicator.BadBuddha_MomoZones(input, enableUpdateChecks, bodyAverageRange, volumeAverageRange, changeBarColor, bodyStdDevs, hotThreshold, showZones, showDots, zoneLookback, enableAlerts, alertOnHotBar, alertOnZoneTest, alertOnZoneBreak, enableZoneInvalidation, consecutiveClosesToInvalidate, enableVolumeWeighting, minZoneOpacity, maxZoneOpacity, showZoneLabels, showVolumeOnLabel, showBodySizeOnLabel, labelFontSize);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddha_MomoZones BadBuddha_MomoZones(bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			return indicator.BadBuddha_MomoZones(Input, enableUpdateChecks, bodyAverageRange, volumeAverageRange, changeBarColor, bodyStdDevs, hotThreshold, showZones, showDots, zoneLookback, enableAlerts, alertOnHotBar, alertOnZoneTest, alertOnZoneBreak, enableZoneInvalidation, consecutiveClosesToInvalidate, enableVolumeWeighting, minZoneOpacity, maxZoneOpacity, showZoneLabels, showVolumeOnLabel, showBodySizeOnLabel, labelFontSize);
		}


		
		public Indicators.BadBuddha_MomoZones BadBuddha_MomoZones(ISeries<double> input , bool enableUpdateChecks, int bodyAverageRange, int volumeAverageRange, bool changeBarColor, double bodyStdDevs, double hotThreshold, bool showZones, bool showDots, int zoneLookback, bool enableAlerts, bool alertOnHotBar, bool alertOnZoneTest, bool alertOnZoneBreak, bool enableZoneInvalidation, int consecutiveClosesToInvalidate, bool enableVolumeWeighting, int minZoneOpacity, int maxZoneOpacity, bool showZoneLabels, bool showVolumeOnLabel, bool showBodySizeOnLabel, int labelFontSize)
		{
			return indicator.BadBuddha_MomoZones(input, enableUpdateChecks, bodyAverageRange, volumeAverageRange, changeBarColor, bodyStdDevs, hotThreshold, showZones, showDots, zoneLookback, enableAlerts, alertOnHotBar, alertOnZoneTest, alertOnZoneBreak, enableZoneInvalidation, consecutiveClosesToInvalidate, enableVolumeWeighting, minZoneOpacity, maxZoneOpacity, showZoneLabels, showVolumeOnLabel, showBodySizeOnLabel, labelFontSize);
		}

	}
}

#endregion
